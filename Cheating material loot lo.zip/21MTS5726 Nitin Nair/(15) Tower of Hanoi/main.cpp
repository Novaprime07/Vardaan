#include <iostream>

using namespace std;
int c=1;
void toh(char from,char to,char via,int n)
{
    if(n!=0)
    {
    toh(from,to,via,n-1);
        //move n from from to to;
    cout<<"STEP "<<c++<<") "<<"Move disks "<<n<<" from tower "<<from<<" to tower "<<to<<endl;
    toh(to,via,from,n-1);
    }
}
int main()
{
    int el;
    cout<<"Enter the number disks you want to play with: ";
    cin>>el;
    cout<<endl;
    toh('A','B','C',el);
    cout<<endl<<"Hope this helped you (>_<)"<<endl<<"Your Welcome (*_*)";
    return 0;
}
