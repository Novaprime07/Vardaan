/*#include <iostream>

using namespace std;

class Stack
{
private:
    int size;
    int*arr;
    int top;
public:
    Stack(int s)
    {
        size=s;
        arr=new int[size];
        top=-1;
    }
    bool isEmpty()
    {
        return top==-1;
    }
    bool isFull()
    {
        return top==size-1;
    }
    void push(int elem)
    {
        if(isFull())
        {
            cout<<"Stack is Full";
            return;
        }
        else
        {
            top++;
            arr[top]=elem;
        }
    }
    int pop()
    {
        if(isEmpty())
        {
            cout<<"Stack is Empty";
            return -1;
        }
        else
        {
            return arr[top--];
        }
    }
    void display()
    {
        if(top>=0)
        {
            cout<<"Stack elements are:"<<" ";
            cout<<"{ ";
            for(int i=top;i>=0; i--)
            {
                cout<<arr[i]<<" ";
            }
            cout<<"}"<<endl;
        }
        else
        {
            cout<<"Stack is empty";
        }
    }
    void elementAtTop()
    {
        if(isEmpty())
        {
            cout<<"Stack is Empty";

        }
        else
        {
            cout<<"Element at top is: "<<arr[top];
        }
    }
};

int main()
{
    int s;
    cout<<"Enter the size of Stack";
    cin>>s;
    Stack mystack(s);
    mystack.push(8);
    mystack.push(9);
    mystack.display();
    mystack.elementAtTop();

}
*/
#include <iostream>
using namespace std;

class Stack
{
private:
    int *arr;
    int top;
    int size;

public:
    Stack(int s)
    {
        size=s;
        top=-1;
        arr=new int[size];
    }
    bool isFull();
    bool isEmpty();
    void push(int el);
    int pop();
    void display();
};

bool Stack::isFull()
{
    return top==size-1;
}
bool Stack::isEmpty()
{
    return top==-1;
}

void Stack::push(int el)
{
    if(isFull())
    {
        cout<<"Stack is full"<<endl;
    }
    else
    {
        top++;
        arr[top]=el;
    }
}

int Stack::pop()
{
    if(isEmpty())
    {

        cout<<"Stack is Empty"<<endl;
        return -1;
    }
    else
    {
        return arr[top];
        top--;
    }
}

void Stack::display()
{
    if(isEmpty())
    {
        cout<<"Stack is empty"<<endl;
    }
    else
        for(int i=top;i>=0;i--)
        {
            cout<<" "<<arr[i]<<" ";
        }
        cout<<endl;
}

int main()
{
    int s;
    cout<<"Enter the size of stack: ";
    cin>>s;
    Stack myStack(s);
    myStack.pop();
    myStack.push(10);
    myStack.push(20);
    myStack.push(30);
    myStack.pop();
    myStack.display();
    return -1;

}
