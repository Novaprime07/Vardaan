#include <iostream>
#include <cmath>
using namespace std;

int Linear_search(int *arr,int el,int size)
{
    //int i;
    //int j;
    for(int i=0;i<size;i++)
    {
      if(arr[i]=el)
        cout<<"Element found"<<endl;
        return -1;
    }
    cout<<"Element Not found";
}

int main()
{
    int arr[]={2,4,1,5,8};
    int el;
    cout<<"Enter the element: ";
    cin>>el;
    int size=sizeof arr/sizeof arr[0];
    Linear_search(arr,el,size);



}
