#include <iostream>
#include <cmath>

using namespace std;

class Queue
{
private:
    int r;
    int f;
    int size;
    int* arr;


public:
    Queue(int s)
    {
        r=f=-1;
        size=s;
        arr=new int[s];
    }
    //void enqueue(int ele);
    //int dequeue();
    //void display();


    int ele;
    int s;
    void enqueue(int ele)
    {
        if(((r==s-1) && (f==0)||(r==(f-1)%s))
        {
            cout<<"queue is full";
            return;
        }
        else if((r==-1)&&(f==-1))
        {
            f=r=0;
            arr[r]=ele;
            return;
        }
        else
        {
            r=(r+1)%s;
            arr[r]=ele;
            return;
        }
    }

    void dequeue()
    {
        if((r==-1)&&(f==-1))
        {
            cout<<"Queue is empty";
            return;
        }
        else if(r==f)
        {
            int temp=arr[f];
            f=r=-1;
            return;
        }
        else
        {
            int temp=arr[f];
            f++;
            return;
        }
    }

    void display()
    {
        if((r==-1)&&(f==-1))
        {
            cout<<"Queue is empty";
            return;
        }
        else if(r>=f)
        {
            cout<<"Queue is:"<<endl;
            for (int i=f;i<=r;i++)
            {
                cout<<arr[i]<<endl;
                return;
            }
        }
        else
        {
            cout<<"Queue is:"<<endl;
            for (int i=f;i<=s;i++)
                cout<<arr[i]<<endl;
            for(int j=0;j<f;j++)
                cout<<arr[j]<<endl;
        }
    }
};


int main()
{
    Queue myqueue(7);
    myqueue.display();
    myqueue.enqueue(10);
    myqueue.display();
    myqueue.enqueue(20);
    myqueue.enqueue(30);
    myqueue.enqueue(40);
    myqueue.enqueue(50);
    myqueue.dequeue();
    myqueue.display();
    myqueue.enqueue(155);
    myqueue.dequeue();
    myqueue.display();

}
