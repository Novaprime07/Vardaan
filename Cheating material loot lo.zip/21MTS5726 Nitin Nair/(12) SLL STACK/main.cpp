#include "SLL.cpp"
int main()
{
    SLL list;
    list.addtohead(1);
    list.addtohead(0);
    list.addtotail(2);
    list.addtotail(3);
    list.addtotail(4);
    list.addtotail(5);
    list.addtotail(6);
    list.addtotail(7);
    cout<<"Elements of the list are: ";
    list.display();
    list.isinlist(6);
    list.deletefromhead();
    list.deletefromtail();
    list.deleteElement(5);
    list.deleteElement(10);
    cout<<"Elements of the list after deletion are: ";
    list.display();
}
