#include <iostream>

using namespace std;

int BinarySearch(int arr[],int f,int l,int el)
{
    int m;
    m=(f+l)/2;
    if(f>l)
    {
        cout<<"Element not found ";
        return -1;
    }

    else
        if(arr[m]==el)
        {
            cout<<"Element found";
            return -1;
        }
        else if(arr[m]>el)
            return BinarySearch(arr,f,m-1,el);
        else if(arr[m]<el)
            return BinarySearch(arr,m+1,l,el);
}

int main()
{
    int arr[]={1,2,3,4,5,6,7,8,9,10};
    BinarySearch(arr,0,10,11);
}
