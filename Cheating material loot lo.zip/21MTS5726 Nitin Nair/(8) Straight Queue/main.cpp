#include <iostream>
#include <cmath>

using namespace std;

class Queue
{
private:
    int f;
    int r;
    int mysize;
    int* arr;

public:
    Queue(int s)
    {
        mysize=s;
        r=-1;
        f=-1;
        arr=new int[s];
    }
    int temp;
    int s;


    void push(int ele)
    {
        if((f==-1)&&(r==-1))
        {
            f=r=0;
            arr[r]=ele;
            return;
        }
        else if((r+1)%mysize==f)
        {
            cout<<"Queue is full";
            return;
        }
        else
        {
            r=(r+1)%mysize;
            arr[r]=ele;
            return;
        }
    }

    int pop()
    {
        if((f==-1)&&(r==-1))
        {
            cout<<"Queue is empty"<<endl;
            return -1;
        }
        else if(f==r)
        {
            temp=arr[f];
            f=r=-1;
            return temp;
        }
        else
        {
            temp=arr[f];
            f++;
            return temp;
        }
    }

    void display()
    {
        if((f==-1)&&(r==-1))
        {
            cout<<"Queue is empty"<<endl;
            return;
        }
        else
        {
            cout<<"Our queue is:"<<endl;
            for(int i=f;i<=r;i++)
            {
                cout<<arr[i]<<endl;
            }
        }
    }
};
int main()
{
    Queue myqueue(7);

    myqueue.display();
    myqueue.push(10);
    myqueue.push(20);
    myqueue.push(30);
    myqueue.push(40);
    myqueue.display();
    myqueue.pop();
    myqueue.display();
    return 0;
}
